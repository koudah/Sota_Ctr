﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Renci.SshNet;

namespace Sota
{
    public partial class Form1 : Form
    {
        static SshClient ssh1;
        static string Host;
        static Boolean Connect_flag;
        static int Index;

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            Index = 0;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            button3.Text = "7A Sotaに接続";
            Connect_flag = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string cd1 = "cd /home/root/SotaSample/bin";
            string cd2 = "/home/vstone/java/jdk1.8.0_40/bin/java -classpath .:/home/vstone/lib/*:/home/vstone/vstonemagic/*:/usr/local/share/OpenCV/java/* -Dfile.encoding=UTF8 jp.vstone.sotasample.";
            string cd3 = "Sota_Jouhouka";
            string Cd;
            //string Cd = "cd /home/root/SotaSample/bin;/home/vstone/java/jdk1.8.0_40/bin/java -classpath .:/home/vstone/lib/*:/home/vstone/vstonemagic/*:/usr/local/share/OpenCV/java/* -Dfile.encoding=UTF8 jp.vstone.sotasample.Hatarakikata";
            Cd = cd1 + ";" + cd2 + cd3;
            MessageBox.Show(Cd);
            if (!ssh1.IsConnected)
            {
                Connect_Sota();
            }
            SshCommand cmd1 = ssh1.CreateCommand(Cd);
            cmd1.Execute();
            MessageBox.Show("おしゃべりが終わりました。");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ssh1.Disconnect();
            Connect_flag = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            comboBox1.Enabled = true;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Connect_Sota();
            if (!ssh1.IsConnected)
            {
                MessageBox.Show("接続エラーです。Sotaの電源、ネットワークを確認して、Sotaに接続ボタンをクリックしてください。");
                return;
            }
            button1.Enabled = true;
            button2.Enabled = true;
            switch (Index)
            {
                case 0:
                    button1.Text = "7A Sota おしゃべり";
                    break;
                case 1:
                    button1.Text = "5階 Sota おしゃべり";
                    break;
                case 2:
                    button1.Text = "4A Sota おしゃべり";
                    break;
                default:
                    break;
            }
            button3.Enabled = false;
        }
        private void Connect_Sota()
        {
            string Host_0 = "192.168.0.12";
            string Host_1 = "192.168.0.12";
            string Host_2 = "192.168.0.12";
            string Port = "22";
            string User = "root";
            string Password = "edison00";

            switch(Index)
            {
                case 0:
                    Host = Host_0;
                    break;
                case 1:
                    Host = Host_1;
                    break;
                case 2:
                    Host = Host_2;
                    break;
                default:
                    Host = Host_0;
                    break;
            }

            ConnectionInfo info = 
                new ConnectionInfo(
                Host,
                Convert.ToInt32(Port),
                User,
                new AuthenticationMethod[] {
                    new PasswordAuthenticationMethod(User, Password)
                }
                );
            ssh1 = new SshClient(info);
            ssh1.Connect();
            MessageBox.Show("Sotaに接続しています。少々お待ちください。");
            if (!ssh1.IsConnected)
            {
                MessageBox.Show("SSH ERROR");
                return;
            }
            Connect_flag = true;
            comboBox1.Enabled = false;
        }

        private void ComboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Index = comboBox1.SelectedIndex;
            switch (Index)
            {
                case 0:
                    button3.Text = "7A Sotaに接続";
                    break;
                case 1:
                    button3.Text = "5階 Sotaに接続";
                    break;
                case 2:
                    button3.Text = "4A Sotaに接続";
                    break;
                default:
                    break;
            }
        }
    }
}
