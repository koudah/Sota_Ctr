package jp.vstone.sotasample;
import java.awt.Color;

import jp.vstone.RobotLib.CPlayWave;
import jp.vstone.RobotLib.CRobotMem;
import jp.vstone.RobotLib.CRobotPose;
import jp.vstone.RobotLib.CRobotUtil;
import jp.vstone.RobotLib.CSotaMotion;
/**
 * VSMDを使用し、モーション再生・音声再生するサンプル
 * @author 幸田　仁
 * 情報化推進WG取り組み説明
 */
public class Sota_Jouhouka {
	static final String TAG = "MotionSample";
	public static void main(String args[]){
		CRobotUtil.Log(TAG, "Start " + TAG);

		CRobotPose pose;
		//VSMDと通信ソケット・メモリアクセス用クラス
		CRobotMem mem = new CRobotMem();
		//Sota用モーション制御クラス
		CSotaMotion motion = new CSotaMotion(mem);

		if(mem.Connect()){
			//Sota仕様にVSMDを初期化
			motion.InitRobot_Sota();

			CRobotUtil.Log(TAG, "Rev. " + mem.FirmwareRev.get());

			//サーボモータを現在位置でトルクOnにする
			CRobotUtil.Log(TAG, "Servo On");
			motion.ServoOn();

			//すべての軸を動作
			pose = new CRobotPose();
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
			,  new Short[]{0   ,-900,0   ,900 ,0   ,0   ,0   ,0}				//target pos
					);

			//LEDを点灯（左目：赤、右目：赤、口：Max、電源ボタン：赤）
			pose.setLED_Sota(Color.RED, Color.RED, 255, Color.RED);

			//遷移時間1000msecで動作開始。
			CRobotUtil.Log(TAG, "play:" + motion.play(pose,1000));

			//補間完了まで待つ
			motion.waitEndinterpAll();

			//今日は情報化推進WGのリーダーの～
			CPlayWave.PlayWave("sound/wg1.wav");
			CRobotUtil.wait(100);
			
			//右手を上げる
			pose = new CRobotPose();
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-36,-847 ,-114,-721,169,137,-21,4}	//target pos
			);
			pose.setLED_Sota(Color.GREEN, Color.GREEN, 255, Color.GREEN);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			CRobotUtil.wait(8000);

						
            //両手を広げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,62,-111,-61,170,137,-21,4}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			//皆さん、築地の情報化推進グループ～
			CPlayWave.PlayWave("sound/wg2.wav");
			CRobotUtil.wait(1000);
			
			//右を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,405,-111,252,186,-452,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
			
			//左を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,-250,-23,-349,170,439,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

           //両手を広げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,62,-111,-61,170,137,-21,4}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

           //両手を前にする。
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-38,-30,-920,10,936,-3,-73,39}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

			CRobotUtil.wait(1000);
			
			//何をやっているのか、誰が知っているのか～
			CPlayWave.PlayWave("sound/wg3.wav");
			CRobotUtil.wait(1000);
			
           //首をかしげる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-33, -30, -902, 3, 903, 2, -67, 308}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			CRobotUtil.wait(10000);
			
			
           //首を戻す
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-33, -33, -902, 4, 903, 3, -68, -14}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //両手を広げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,62,-111,-61,170,137,-21,4}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			//こんな印象をお持ちでは～
			CPlayWave.PlayWave("sound/wg4.wav");
			CRobotUtil.wait(8000);
			
           //頭抱える
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-46,337,-308,-233,697,3,125,10}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

			//情報化推進のメンバーになったものの～
			CPlayWave.PlayWave("sound/wg5.wav");
			CRobotUtil.wait(1000);			
			
           //頭抱えて首を右
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-50,295,-492,-187,697,-717,120,0}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //頭抱えて首を左
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-30,298,-498,-158,696,811,121,16}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			//頭抱えて首を右
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-50,295,-492,-187,697,-717,120,0}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //頭抱えて首を左
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-30,298,-498,-158,696,811,121,16}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();
			
			//頭抱えて首を右
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-50,295,-492,-187,697,-717,120,0}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //頭抱えて首を左
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-30,298,-498,-158,696,811,121,16}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();
			
			//頭抱えて首を右
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-50,295,-492,-187,697,-717,120,0}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //頭抱えて首を左
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-30,298,-498,-158,696,811,121,16}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();			
			
						
			//頭抱えて首を右
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-50,295,-492,-187,697,-717,120,0}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

           //頭抱えて首を左
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-30,298,-498,-158,696,811,121,16}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();			
						
           //首をもとに
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-46,337,-308,-233,697,3,125,10}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			CRobotUtil.wait(4500);			
			
			//両手を広げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,62,-111,-61,170,137,-21,4}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

			//こういった、情報化推進の～
			CPlayWave.PlayWave("sound/wg6.wav");
			CRobotUtil.wait(1000);
			
            //右を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,405,-111,252,186,-452,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
			
			//左を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,-250,-23,-349,170,439,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
			
            //右を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,405,-111,252,186,-452,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
			
			//左を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,-250,-23,-349,170,439,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
            //右を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,405,-111,252,186,-452,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
			
			//左を見る
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,-250,-23,-349,170,439,-43,9}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();
												
			//両手を広げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,62,-111,-61,170,137,-21,4}	//target pos
			);
			motion.play(pose,1500);
			motion.waitEndinterpAll();

			CRobotUtil.wait(10000);						
			
			//あいさつのために頭を上げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,135,-587,137,689,135,-303,13}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

			//ありがとうございました
			CPlayWave.PlayWave("sound/wg7.wav");
			CRobotUtil.wait(1000);
			
			//あいさつのために頭を下げる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
						,  new Short[]{-37,-843,-113,806,173,135,118,9}	//target pos
			);
			motion.play(pose,1000);
			motion.waitEndinterpAll();


			//正面をみる
			pose.SetPose(new Byte[] {1   ,2   ,3   ,4   ,5   ,6   ,7   ,8}	//id
			,  new Short[]{0   ,-900,0   ,900 ,0   ,0   ,0   ,0}				//target pos
					);
			motion.play(pose,1000);
			motion.waitEndinterpAll();

				
			pose.setLED_Sota(Color.BLUE, Color.BLUE, 255, Color.BLUE);
			motion.play(pose,1000);
			motion.waitEndinterpAll();
			
			pose.setLED_Sota(Color.BLACK,Color.BLACK,0, Color.GREEN);
			motion.play(pose,1000);
			motion.waitEndinterpAll();		

			//サーボモータのトルクオフ
			CRobotUtil.Log(TAG, "Servo Off");
			motion.ServoOff();
		}
	}
}
